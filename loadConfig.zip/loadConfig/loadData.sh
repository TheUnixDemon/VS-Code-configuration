cp ./data/*.json ~/.config/Code/User/snippets/ || echo "failed"
